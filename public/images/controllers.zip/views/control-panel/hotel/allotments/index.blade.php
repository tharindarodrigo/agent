@extends('control-panel.hotel.allotments.allotments')

@section('rate-content')

<div class="col-md-12">
    <div class="box box-primary">
        <!-- /.box-header -->
        <div class="box-body table-responsive">
            <table class="table table-bordered table-striped" id="rooms-table">
            <thead>
                <tr>
                    <th></th>
                </tr>
            </thead>
            <tbody>

            </tbody>
            </table>
        </div>
    </div>
</div>


@endsection