@extends('control-panel.layout.main')

@section('content')

    <div class="col-md-12">
        <div class="box box-default">
            <div class="box-header with-border">
                <h3>Welcome To the Control Panel</h3>
            </div>
            <div class="box-body">

            </div>

        </div>
    </div>


@endsection

@section('active-dashboard')

    {{'active'}}

@stop
