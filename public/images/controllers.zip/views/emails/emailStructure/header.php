<!DOCTYPE html>

<html>

<head>
    <meta charset="utf-8">


</head>
<body style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
            font-size: 12px;">
<div class="container">
    <div class="row">

        <div style="">
            <div style="width:200px; padding-left: 100px;" ></div>
            <div>
                <div>
                    <div>
                        <table width="100%">
                            <tr>
                                <td>
                                    <img src="<?php echo public_path()?>/images/site/ehilogo2.png" alt="logo" height="100%">
<!--                                    --><?php //echo HTML::image("/images/site/ehilogo2.png"); ?><!--</td>-->
                                <td align="right"><h5 style="text-align: right"><strong>Date:</strong> <?php echo date('Y-m-d'); ?></h5>
                                    <h5 style="text-align: right"><strong>Time:</strong> <?php echo date('H:i'); ?></h5></td>
                            </tr>
                        </table>

<!--                        --><?php //echo HTML::image("/images/site/ehilogo2.png"); ?>
                    </div>

                    <br/>
                    <hr/>

                </div>