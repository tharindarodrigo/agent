<div
    style="text-align: center; color:#ffffff; background: #00517e; padding: 20px; border-bottom-left-radius: 5px; border-bottom-right-radius: 5px;">
    <div style="text-align: center; ">
        <a class="btn btn-success" style="color: inherit;" href="#">SriLankaHotels.travel</a>
        | <a class="btn btn-danger" style="color: inherit;" href="#">Contact</a>
        | <a style="color: inherit;" href="#">Link</a>
    </div>
    <p></p>

    <p style="text-align: center; text-decoration: none; color: inherit;"><strong>Email:
            info@srilankahotels.travel</strong></p>

    <p style="text-align: center; color: inherit;"><strong>Fax: 011 4 789 789 | Tel: 011 4 123 123</strong></p>
</div>

</div>


<script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</body>
</html>