<!DOCTYPE html>

<html>

<head>
    <meta charset="utf-8">

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
</head>
<body style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
            font-size: 12px;">
<div>
    <div>
        <div>
            <table width="100%">
                <tr>
                    <td>
                        <img src="<?php echo public_path() ?>/images/site/ehilogo2.png" alt="logo"
                             height="100%">
                        <!--                                    --><?php //echo HTML::image("/images/site/ehilogo2.png"); ?>
                    </td>
                    <td align="right">
                        <div style="padding-top: 20px;">
                            <ul style="list-style: none;">
                                <li><b>ADDRESS:&nbsp;</b> #07, Barnes Avenue, Mount Lavinia, Sri Lanka</li>
                                <li><b>TEL:&nbsp;</b> +94 11 5234585</li>
                                <li><b>FAX:&nbsp;</b> +94 11 5231245-6</li>
                                <li><b>WEB:&nbsp;</b> www.srilankahotels.travel</li>
                                <li><b>EMAIL:&nbsp;</b> info@srilankahotels.travel</li>
                                <!--                                        </ul>-->
                        </div>
                    </td>
                </tr>
            </table>

        </div>

        <br/>
        <hr/>

    </div>


