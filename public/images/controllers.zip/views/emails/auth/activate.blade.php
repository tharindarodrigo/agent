Hello {{ $first_name }}, <br /> <br />

Please activate your account using the following link <br /> <br />

----<br />

{{ $link }} <br />

----