Hello {{ $first_name }} <br />

It looks like you requested a new password. You'll need to use the following link, <br /><br />

New Password : {{ $password }}<br><br>

------------------------------------------------<br>

{{ $link }}

<br>------------------------------------------------