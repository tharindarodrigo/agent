<p>Dear {{$first_name}},</p>

<p>Thank you for Signing Up with us as {{($role == 'Agent' ? 'an ' : 'a ').$role }}</p>
<p>We will contact you within 24 hours to confirm you as {{($role == 'Agent' ? 'an ' : 'a ').$role }}</p>

<p>We will guide you through our process</p>
<p>Hoping to see you in business with us</p>

<p>Thank you!</p>